class alldef:
    def __init__():
        pass

